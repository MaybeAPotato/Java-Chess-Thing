/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chessStuff;

/**
 *
 * @author User
 */
public class emptySpace implements pieceInterface {
    String sPieceName;
    
    @Override
    public void setPlayer(int _nPlayer){ //Sets the piece's controlling player
        sPieceName = "--";
    }
    
    @Override
    public void setPos(int _nX, int _nY){
    }
    
    @Override
    public boolean movePiece(int _nX, int _nY,  int[][] _arBoard2){ //Attempts to move piece
        return false;
    }
    
    @Override
    public String getName(){ //Get piece name
        return sPieceName;
    }
    
}
